
double menuWidth = 230;

double headerHeight = 80;