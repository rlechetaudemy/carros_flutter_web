import 'package:flutter/material.dart';

class AppColors {
  static const blue = Color.fromARGB(255, 21, 61, 110);
}