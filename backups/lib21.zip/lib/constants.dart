
double headerHeight = 80;

double menuWidth = 230;