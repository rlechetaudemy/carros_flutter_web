
final user = Usuario(
  "Admin",
  "https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg",
);

class Usuario {
  String nome;
  String urlFoto;

  Usuario(this.nome, this.urlFoto);
}