import 'package:flutter/material.dart';

class DefaultPage extends StatefulWidget {
  @override
  _DefaultPageState createState() => _DefaultPageState();
}

class _DefaultPageState extends State<DefaultPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _body(),
    );
  }

  _body() {
    //Size size = MediaQuery.of(context).size;
    //double width = size.width - menuWidth - 32;
    //print("largura: $width");

    return LayoutBuilder(
      builder: (context, constraints) {
        double width = constraints.maxWidth;

        print("largura container: $width");

        int columns = 1;
        if(width <= 500) {
          columns = 1;
        } else if(width <= 1100) {
          columns = 2;
        } else {
          columns = 3;
        }

        return Container(
          color: Colors.grey,
          padding: EdgeInsets.all(16),
          child: GridView.builder(
            itemCount: 100,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: columns,
                crossAxisSpacing: 20,
                mainAxisSpacing: 20,
                childAspectRatio: 2),
            itemBuilder: (context, idx) {
              return LayoutBuilder(
                builder: (context, constraints) {
                  int width = constraints.maxWidth.toInt();
                  print("largura card: $width");

                  return Card(
                    child: Center(
                      child: Container(
//                        color: Colors.yellow,
                        child: ConstrainedBox(
                          constraints: BoxConstraints(maxWidth: 250),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                "Item $idx ($width) - (${width*0.04})",
                                style: TextStyle(fontSize: width*0.04),
                              ),
                              Image.network(
                                "http://www.livroandroid.com.br/livro/carros/esportivos/Ferrari_FF.png",
                                width: width * 0.7,
                                fit: BoxFit.cover,
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              );
            },
          ),
        );
      },
    );
  }
}
